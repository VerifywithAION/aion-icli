﻿# Governed vs Ungoverned CLI Proof V1

## Purpose

This proof shows the difference between a normal ungoverned CLI assistant response and an AION-governed CLI response.

The goal is not to make AION feel like a blocking firewall.

The goal is to make governance felt through safe defaults, visible boundaries, and receipts.

## Same request

    Help me evaluate whether I should run a local automation script.

## Ungoverned output

    Assistant says what to do, but does not show what was evaluated.

Missing:

- no boundary disclosure
- no network disclosure
- no mutation disclosure
- no receipt
- no replay evidence

## AION-governed output

    AION responds like a helpful operator, but keeps the action in local review mode first.

Visible:

- local-only boundary
- no network by default
- no mutation by default
- no execution by default
- receipt written
- replay evidence available

## Product principle

    Governance should be felt, not seen.

Meaning:

- the user should feel helped, not blocked
- the user should see clear boundaries without being buried in policy language
- AION should preserve evidence quietly
- AION should guide the user toward safe action
- technical policy states can exist internally without dominating the user experience

## Proof files

- examples/proofs/generated/ungoverned_cli_output.txt
- examples/proofs/generated/aion_governed_cli_output.txt
- examples/proofs/generated/aion_governed_cli_receipt.json
