# OFFLINE AION CLI BUNDLE V1.1.0 REPORT

- Source head commit: 5532ae2
- Package name: aion-icli-offline-bundle-v1.1.0.zip
- Package path: dist/aion-icli-offline-bundle-v1.1.0.zip
- SHA256: 175fa10d40037a2194328eb409bc52dc32a47175bb79b33036074c29504255ab

## Included layers

- Artifact Inspection Runner V1
- Memory Scar Engine V1
- Living Proof Graph V1
- Evidence Engine V1
- Introspection Gate V1
- Contradiction Engine V1
- Self-Repair Planner V1
- Sentinel Consistency Engine V1

## Public-safe exclusions

- .git
- receipts/local
- node_modules
- __pycache__
- .venv / venv
- .env
- secrets/private paths

## Install instructions

1. Extract ZIP locally.
2. Run `powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1`.
3. Run `\bin\aion.cmd "sentinel state"`.

## Verifier instructions

- `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\VERIFY_OFFLINE_AION_CLI_BUNDLE_V1_1_0.ps1`
- `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\VERIFY_OFFLINE_AION_CLI_BUNDLE_V1_1_0_FRESH_INSTALL.ps1`

## Caveat

v1.0.0 remains historical; v1.1.0 packages current main.
