# Sentinel Consistency Engine V1 Summary

- Sentinel state: DEGRADED_NEEDS_REPAIR
- Blocking: false
- Highest severity: MEDIUM
- Accepted caveats: 1
- Open contradictions: 1
- Repair items: 3
- Next required action: rebuild_public_offline_bundle_v1_1_0
